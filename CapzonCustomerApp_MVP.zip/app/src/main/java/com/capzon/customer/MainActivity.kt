package com.capzon.customer

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

data class Food(val id:Int,val name:String,val category:String,val price:Int,val emoji:String,val desc:String)

class MainActivity : AppCompatActivity() {
    private val foods = listOf(
        Food(1,"Margherita Pizza","Pizza",149,"🍕","Classic cheese & tomato"),
        Food(2,"Paneer Tikka Pizza","Pizza",219,"🍕","Paneer tikka, capsicum & cheese"),
        Food(3,"Onion Capsicum Pizza","Pizza",179,"🍕","Onion, capsicum & cheese"),
        Food(4,"Paneer Cheese Burger","Burger",129,"🍔","Paneer patty with cheese"),
        Food(5,"Veg Burger","Burger",89,"🍔","Crispy veg patty"),
        Food(6,"Steamed Veg Momos","Momos",99,"🥟","Soft momos with chutney"),
        Food(7,"Kurkure Momos","Momos",139,"🥟","Crispy outside, spicy inside"),
        Food(8,"White Sauce Pasta","Pasta",149,"🍝","Creamy cheesy pasta"),
        Food(9,"Veg Chowmein","Chinese",109,"🍜","Stir-fried vegetables & noodles"),
        Food(10,"Veg Thali","Lunch",149,"🍱","Complete vegetarian meal"),
        Food(11,"Special Paneer Thali","Lunch",199,"🍛","Special paneer meal"),
        Food(12,"Masala Chai","Breakfast",20,"☕","Hot Indian tea"),
        Food(13,"Bread Pakoda","Breakfast",40,"🥪","2 pieces per plate"),
        Food(14,"Extra Cheese","Add-ons",30,"🧀","Extra cheese"),
        Food(15,"Cold Drink","Add-ons",40,"🥤","Chilled drink")
    )
    private val cart = mutableMapOf<Int,Int>()
    private lateinit var root: LinearLayout

    private fun dp(v:Int)= (v*resources.displayMetrics.density).toInt()
    private fun tv(text:String,size:Float,bold:Boolean=false): TextView {
        return TextView(this).apply {
            this.text=text; textSize=size
            setTextColor(Color.rgb(25,25,25))
            if(bold) setTypeface(typeface, android.graphics.Typeface.BOLD)
            setPadding(dp(4),dp(5),dp(4),dp(5))
        }
    }
    private fun button(text:String,onClick:()->Unit): Button =
        Button(this).apply { this.text=text; setOnClickListener{onClick()} }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showHome()
    }

    private fun shell(title:String) {
        root = LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setBackgroundColor(Color.rgb(247,248,247))
        }
        val header=LinearLayout(this).apply {
            orientation=LinearLayout.HORIZONTAL
            gravity=Gravity.CENTER_VERTICAL
            setPadding(dp(16),dp(16),dp(16),dp(12))
            setBackgroundColor(Color.rgb(23,107,67))
        }
        val brand=tv(title,21f,true); brand.setTextColor(Color.WHITE)
        header.addView(brand,LinearLayout.LayoutParams(0,dp(55),1f))
        val cartBtn=button("🛒 ${cart.values.sum()}"){showCart()}
        header.addView(cartBtn,LinearLayout.LayoutParams(dp(90),dp(55)))
        root.addView(header)
        val scroll=ScrollView(this)
        val body=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(14),dp(14),dp(14),dp(30))}
        scroll.addView(body); root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root)
        body.tag="body"
    }
    private fun body():LinearLayout = (root.findViewWithTag("body") as LinearLayout)

    private fun showHome() {
        shell("Capzon Restaurant")
        val b=body()
        b.addView(tv("Fresh • Veg • Delivered to you",14f))
        val search=EditText(this).apply{hint="Search pizza, burger, momos...";setSingleLine()}
        b.addView(search,LinearLayout.LayoutParams(-1,dp(55)))
        val cats=listOf("All","Pizza","Burger","Momos","Pasta","Chinese","Breakfast","Lunch","Add-ons")
        val catRow=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        cats.forEach { c ->
            val bt=button(c){renderFoods(c,search.text.toString())}
            catRow.addView(bt,LinearLayout.LayoutParams(dp(95),dp(55)))
        }
        b.addView(catRow)
        val list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        b.addView(list)
        fun render() {
            list.removeAllViews()
            val q=search.text.toString().trim().lowercase()
            foods.filter{(q.isEmpty()||it.name.lowercase().contains(q))}.forEach{f->
                val card=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(8),dp(8),dp(8),dp(8));setBackgroundColor(Color.WHITE)}
                val icon=tv(f.emoji,34f); card.addView(icon,LinearLayout.LayoutParams(dp(62),dp(70)))
                val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
                info.addView(tv(f.name,16f,true)); info.addView(tv(f.desc,12f))
                info.addView(tv("₹${f.price}",16f,true))
                card.addView(info,LinearLayout.LayoutParams(0,dp(85),1f))
                card.addView(button(if(cart[f.id]==null)"Add +" else "+ ${cart[f.id]}"){cart[f.id]=(cart[f.id]?:0)+1;showHome()})
                val lp=LinearLayout.LayoutParams(-1,dp(100));lp.setMargins(0,dp(7),0,0);list.addView(card,lp)
            }
        }
        search.addTextChangedListener(object:android.text.TextWatcher{
            override fun beforeTextChanged(s:CharSequence?,st:Int,c:Int,a:Int){}
            override fun onTextChanged(s:CharSequence?,st:Int,b:Int,c:Int){render()}
            override fun afterTextChanged(s:android.text.Editable?){}
        })
        render()
    }
    private fun renderFoods(cat:String,q:String) {
        // Category buttons restart the home screen with filtered data in this MVP.
        shell("Capzon Restaurant")
        val b=body()
        b.addView(tv("$cat Menu",20f,true))
        foods.filter{cat=="All"||it.category==cat}.forEach{f->
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;setPadding(dp(8),dp(8),dp(8),dp(8));setBackgroundColor(Color.WHITE)}
            row.addView(tv(f.emoji,32f),LinearLayout.LayoutParams(dp(55),dp(70)))
            val info=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
            info.addView(tv(f.name,16f,true));info.addView(tv(f.desc,12f));info.addView(tv("₹${f.price}",16f,true))
            row.addView(info,LinearLayout.LayoutParams(0,dp(80),1f))
            row.addView(button(if(cart[f.id]==null)"Add +" else "+ ${cart[f.id]}"){cart[f.id]=(cart[f.id]?:0)+1;showHome()})
            val lp=LinearLayout.LayoutParams(-1,dp(92));lp.setMargins(0,dp(7),0,0);b.addView(row,lp)
        }
    }
    private fun showCart() {
        shell("Your Cart")
        val b=body()
        if(cart.isEmpty()){
            b.addView(tv("🛒",50f));b.addView(tv("Your cart is empty",20f,true));b.addView(button("Browse Menu"){showHome()});return
        }
        cart.toMap().forEach{(id,n)->
            val f=foods.first{it.id==id}
            val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL}
            row.addView(tv("${f.emoji}  ${f.name}",16f,true),LinearLayout.LayoutParams(0,dp(60),1f))
            row.addView(button("−"){cart[id]=(cart[id]?:1)-1;if(cart[id]!!<=0)cart.remove(id);showCart()})
            row.addView(tv(" $n ",16f,true))
            row.addView(button("+"){cart[id]=(cart[id]?:0)+1;showCart()})
            b.addView(row)
        }
        val total=cart.entries.sumOf{(id,n)->foods.first{it.id==id}.price*n}
        b.addView(tv("Total: ₹$total",22f,true))
        b.addView(button("Proceed to Checkout"){showCheckout()})
    }
    private fun showCheckout() {
        shell("Checkout")
        val b=body()
        val total=cart.entries.sumOf{(id,n)->foods.first{it.id==id}.price*n}
        b.addView(tv("Order Total: ₹$total",22f,true))
        val name=EditText(this).apply{hint="Customer name"}
        val phone=EditText(this).apply{hint="10-digit mobile number";inputType=2}
        val address=EditText(this).apply{hint="Delivery address";minLines=3}
        listOf(name,phone,address).forEach{b.addView(it,LinearLayout.LayoutParams(-1,dp(60)))}
        b.addView(tv("Payment",16f,true))
        val pay=RadioGroup(this)
        val cod=RadioButton(this).apply{text="Cash on Delivery";isChecked=true}
        val online=RadioButton(this).apply{text="Online Payment"}
        pay.addView(cod);pay.addView(online);b.addView(pay)
        b.addView(button("Place Order"){ 
            if(name.text.isBlank()||phone.text.length!=10||address.text.isBlank()){
                Toast.makeText(this,"Please fill name, 10-digit mobile and address",Toast.LENGTH_LONG).show()
            } else {
                val order="CAP-"+(1000..9999).random()
                cart.clear()
                shell("Order Confirmed")
                val bb=body();bb.gravity=Gravity.CENTER_HORIZONTAL
                bb.addView(tv("✅",55f));bb.addView(tv("Order Confirmed!",24f,true))
                bb.addView(tv("Order #$order",16f));bb.addView(tv("Total: ₹$total",20f,true))
                bb.addView(tv("Payment: ${if(cod.isChecked)"Cash on Delivery" else "Online Payment"}",15f))
                bb.addView(button("Back to Menu"){showHome()})
            }
        })
    }
}
