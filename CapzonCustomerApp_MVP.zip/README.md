# Capzon Customer App - Android MVP

This is a native Android Kotlin MVP for Capzon Restaurant.

Included:
- Home/menu
- Search
- Categories
- Add to cart
- Quantity controls
- Checkout
- Customer name/mobile/address
- COD / Online Payment selection (online payment is placeholder)
- Demo order confirmation

Important:
- This version is a local MVP. Orders are NOT sent to the restaurant yet.
- Online payment is only a selection placeholder.
- Backend/database, push notifications, admin panel, delivery logic and payment gateway must be connected for production.

Open this folder in Android Studio and run the app on an Android phone/emulator.
